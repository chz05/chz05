#include "HCTree.hpp"
#include <vector>

void build(const vector<int>& freqs){
	//create a 2D vector to store the i and freqs
	unorderd_map<byte, int> mp = 

}


void encode(unsigned char symbol, FancyOutputStream & out) const{
	
}
