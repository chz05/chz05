#include <algorithm>
#include <iostream>



int main(int argc, char* argv[]){
	//./compress <original_file> <compressed_file>
	if (argc != 3)
		throw std::runtime_err();
}
// void getInputFileName(){
// 	char* filename;
// 	cout << "Please Enter your file name: ";
// 	cin >> filename;
// 	FancyInputStream input = FancyInputStream(filename);

// }
